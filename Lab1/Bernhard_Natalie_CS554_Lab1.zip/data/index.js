const taskData = require('./tasks');

module.exports = {
    tasks: taskData
};
